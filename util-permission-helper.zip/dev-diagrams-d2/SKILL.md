---
name: dev-diagrams-d2
description: Use when generating diagrams with D2 - covers syntax, layout engines, themes, and the MCP tool for rendering to PNG
---

# D2 Diagrams

## Overview

Generate diagrams using D2 syntax, rendered to PNG or SVG via the mcp-d2-diagrams MCP server.

**Announce at start:** "Using D2 diagram skill."

## MCP Tool

```
mcp__mcp-d2-diagrams__generate_d2_diagram
  - d2: D2 diagram syntax (required)
  - output_path: absolute path including filename (required)
  - layout: dagre | elk (default: elk)
  - theme: integer 0+ (default: 0)
  - sketch: boolean (default: false)
  - pad: integer pixels of padding (default: 100)
  - scale: float output scale, -1 = auto (default: -1)
```

**IMPORTANT:** Before calling this tool, ask the user where they want the diagram saved if they haven't specified an output location.

### Output format

The file extension determines the format:
- `.png` — Use by default. Claude Code's Read tool displays PNGs visually.
- `.svg` — Use when embedding in Confluence, PDFs, web pages, or docs. Claude Code shows SVGs as raw XML (not useful for visual review).

### Output location

If the user hasn't specified a location, suggest:
- The current working directory for quick/throwaway diagrams
- A `diagrams/` subdirectory of the current project for project diagrams
- A path alongside related documentation if generating for a specific doc

## D2 Syntax Quick Reference

### Connections

```d2
# Basic connection
a -> b

# Labeled connection
a -> b: sends data

# Bidirectional
a <-> b: syncs

# Chained
a -> b -> c -> d

# Self-referencing
server -> server: health check
```

### Shapes

```d2
# Default (rectangle)
my_service

# With label
my_service: My Service

# Explicit shape
my_db: PostgreSQL {
  shape: cylinder
}

# Available shapes: rectangle, square, page, parallelogram, document,
# cylinder, queue, package, callout, stored_data, person,
# diamond, oval, circle, hexagon, cloud
# NOTE: "step" is NOT a valid shape despite appearing in some docs — use rectangle instead
```

### Containers (grouping)

```d2
# Nested container
backend: Backend {
  api: API Server
  db: Database {
    shape: cylinder
  }
  api -> db
}

frontend: Frontend {
  app: React App
}

frontend.app -> backend.api: REST
```

### Styles

```d2
my_node: Important {
  style: {
    fill: "#ff6b6b"
    stroke: "#333"
    font-color: "#fff"
    bold: true
    border-radius: 8
    opacity: 0.9
  }
}

my_connection -> target: critical {
  style: {
    stroke: red
    stroke-dash: 3
    stroke-width: 2
    animated: true
  }
}
```

### Icons

```d2
# Using built-in icons (requires internet on first use)
server: Server {
  icon: https://icons.terrastruct.com/essentials%2F112-server.svg
}
```

### Multiple Connections Between Same Nodes

```d2
# Use unique IDs
a -> b: http
a -> b: grpc {
  style.stroke-dash: 3
}
```

### SQL Tables

```d2
users: {
  shape: sql_table
  id: int {constraint: primary_key}
  name: varchar
  email: varchar {constraint: unique}
}
```

## Layout Engines

| Engine | Flag | Best For |
|--------|------|----------|
| **ELK** (default) | `--layout=elk` | Complex nested diagrams, many connections |
| **dagre** | `--layout=dagre` | Simple hierarchies, faster rendering |

ELK is recommended for most cases. Dagre is faster but handles complex nesting poorly.

## Themes

| ID | Name | Use Case |
|----|------|----------|
| 0 | Default | General purpose |
| 1 | Neutral Grey | Professional docs |
| 3 | Flagship Terrastruct | Branded, colorful |
| 4 | Cool Classics | Blue-toned |
| 5 | Mixed Berry Blue | Dark blue |
| 6 | Grape Soda | Purple |
| 7 | Aubergine | Dark purple |
| 8 | Colorblind Clear | Accessibility |
| 100 | Terminal | Retro/dev |
| 101 | Terminal Grayscale | Monochrome |
| 102 | Terminal Dark | Dark terminal |
| 200 | Origami | Paper-like |

Use `sketch: true` for hand-drawn informal look (works with any theme).

## Filename Convention

- Use `snake_case.png` or `snake_case.svg`
- No spaces in filenames
- Store source `.d2` alongside generated output for editability

## Common Errors

| Error | Cause | Fix |
|---|---|---|
| `unexpected field shape` | Used `shape: step` — not valid | Use `shape: rectangle` instead |
| `unexpected field shape` | Node named `label` inside a container | Rename to `label_text` or similar — `label` is a reserved D2 keyword |
| Node not found | Cross-container reference like `a.b -> c.d` | Ensure both nodes exist and IDs match exactly |

## Related Skills

- For Mermaid diagrams (simpler syntax, fewer layout options): `/dev-diagrams-mermaid`
- For uploading diagrams to Confluence: `/dev-confluence`
- For embedding diagrams in PDFs: `/dev-markdown-to-pdf`
