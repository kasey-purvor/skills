---
name: dev-diagrams-mermaid
description: Use when generating diagrams with Mermaid - covers syntax, diagram types, layout tips, and the MCP tool for rendering to PNG
---

# Mermaid Diagrams

## Overview

Generate diagrams using Mermaid syntax, rendered to PNG via the mcp-mermaid MCP server.

**Announce at start:** "Using Mermaid diagram skill."

## MCP Tool

```
mcp__mcp-mermaid__generate_mermaid_diagram
  - mermaid: diagram syntax (required)
  - output_path: absolute path including filename (required)
  - theme: default | base | forest | dark | neutral
  - backgroundColor: CSS color (default: white)
```

**IMPORTANT:** Before calling this tool, ask the user where they want the diagram saved if they haven't specified an output location.

## Layout Tips

- Use `flowchart TB` (top-to-bottom) for vertical layouts — good for Confluence pages and narrow contexts
- Use `flowchart LR` (left-to-right) for pipelines and wide layouts
- Use `direction LR` within subgraphs if you need horizontal sections inside a vertical flow

## Filename Convention

- Use `snake_case.png`
- No spaces in filenames
- Store source `.mmd` alongside generated `.png` for editability

## Related Skills

- For D2 diagrams (better auto-layout for complex diagrams): `/dev-diagrams-d2`
- For uploading diagrams to Confluence: `/dev-confluence`
- For embedding diagrams in PDFs: `/dev-markdown-to-pdf`
