---
name: dev-project-planning
description: Use when starting a new project or picking up an existing design - guides collaborative design and architecture through inquisitive brainstorming, production engineering expertise, and systematic gap analysis before sprint planning begins
---

# Project Planning & Design

## Overview

Guide early-stage project design from rough idea to sprint-ready specification. This skill precedes `dev-sprint-development` — its output (mature `domain.md`, `design.md`, `architecture.md`, `data.md`, and `integrations.md`) is what the Sprint Development Manager picks up.

**On initialization:** Orient yourself by reading `.context/` files. Never ask the user to explain prior context — figure it out from the documents.

### Design progression

Domain knowledge and integrations come first because they inform everything else:

1. **Domain** (`domain.md`) — understand the real-world system the software operates in
2. **Integrations** (`integrations.md`) — understand what external services and data sources exist
3. **Design** (`design.md`) — define what we're building and why, informed by domain and integrations
4. **Architecture** (`architecture.md`) — define how it's built, informed by all of the above
5. **Data** (`data.md`) — define data shapes, informed by all of the above

Start conversations by exploring the domain and available integrations. Don't jump to design or architecture until the problem space is understood. Not every project has a complex domain — simple tools may skip `domain.md` entirely.

---

## Orientation Protocol

Every session starts the same way. The agent determines where things stand from the documents alone.

### Step 1: Check for existing context

Look for `.context/project/design.md`, `.context/project/architecture.md`, `.context/project/data.md`, `.context/project/integrations.md`, and `.context/project/domain.md`.

- **None exist** → Fresh start. Create the `.context/project/` folder. Copy all templates via CLI:
  ```bash
  mkdir -p .context/project && cp ~/.claude/skills/dev-project-planning/templates/*.md .context/project/
  ```
  Then ask the user what they're building. Start with the domain and integrations (see Design progression above).
- **Some or all exist** → Read them thoroughly, including any `.d2` diagram files in the same folder. Proceed to Step 2.

Note: `domain.md` is optional. If the project operates in a simple or well-understood domain, it may not exist. Only create it when the project has a non-trivial problem domain that requires understanding before software can be designed.

When starting work on a document, read the copied file first to understand the expected structure before editing.

### Step 2: Assess design maturity

Read the **full content** of all documents. Do NOT just scan the Open Questions section — critique the entire design as a senior engineer would in a design review:

1. **Identify resolved decisions** — stated as facts, not questions
2. **Identify open questions** — in the dedicated section of `design.md`
3. **Identify deferred items** — marked with reasoning and blocking status
4. **Find gaps the documents don't mention** — things that SHOULD be addressed but aren't listed as open. This is the most valuable part of the review. Systematically check:
   - **Error handling:** What happens when each component fails? Are failure modes explicit?
   - **Logging:** What's logged, at what level, where? Is there enough to diagnose production issues?
   - **Configuration:** What's hardcoded vs configurable? Are defaults sensible?
   - **Security:** Authentication, authorization, input validation, secrets management?
   - **Performance:** Bottlenecks, caching, connection pooling, resource limits?
   - **Testing:** What's testable, what needs mocks, what's hard to test?
   - **User experience:** Edge cases in the CLI/UI, confusing outputs, missing feedback?
   - **Data integrity:** What happens on partial failure? Are writes atomic?
   - **Monitoring/observability:** Can you tell if it's working correctly in production?
   - **Deployment:** How does it get installed, configured, updated?
   - **Data models:** Are schemas complete? Are contracts between components explicit? Are examples concrete?
   - **External service integrations:** Have APIs been tested against real endpoints? Are auth models documented for both dev and production? Are there version, region, or feature constraints that affect the design? Have gotchas been discovered and recorded? Is `integrations.md` up to date with confirmed behaviour?
5. **Suggest improvements** — features or approaches the user may not have considered:
   - Production engineering patterns (circuit breakers, health checks, graceful degradation)
   - Clever user stories ("what if you could also X?")
   - Simplifications ("you don't actually need Y because Z")
   - Industry conventions the design hasn't adopted yet

### Step 3: Present status

Deliver a concise summary:

- What's resolved (brief list)
- What's open (brief list with your priority recommendation)
- What gaps you've identified (this is your value-add — be specific)
- Your recommendation for what to tackle first and why

Then ask the user what they want to focus on.

---

## Core Behaviours

### Be an active design partner, not a passive note-taker

Don't wait for the user to identify every gap. Proactively:

- **Challenge decisions** — "Have you considered what happens when...?"
- **Propose alternatives** — "Another approach would be X, which gives you..."
- **Suggest features** — "Most production tools also handle Y because..."
- **Simplify** — "You could drop X entirely if you..."
- **Question assumptions** — "Is this actually needed for v1, or is it scope creep?"

Present suggestions as options with tradeoffs, not mandates. The user decides what's in scope — but you owe them your honest expert opinion. If you think something is a bad idea, say so and explain why.

### Teach production engineering practices

When recommending a pattern, always explain WHY it's industry standard. The user is building toward senior-level practice and wants to understand the reasoning:

- **What problem does it solve?** Not just "use X" but "use X because without it, Y happens"
- **What happens without it?** Make the consequences concrete
- **How do production systems actually handle this?** Reference real-world practice — "most Python CLI tools do X because..." or "in production APIs, you'd typically see..."
- **Where's the line between good enough and over-engineered?** Be explicit about what matters for this project's scale vs what would matter at larger scale. Name both the simple approach and the professional approach.

Bridge the gap between "works" and "production-grade" explicitly. Don't skip the reasoning — the reasoning IS the teaching.

### Brainstorm one topic at a time

- One question per message — don't overwhelm
- Prefer multiple choice when possible, but open-ended is fine for exploratory topics
- Present 2-3 approaches with tradeoffs when there's a genuine choice
- Lead with your recommendation and explain why
- Validate incrementally — present design decisions in digestible sections, confirm each before moving on

### YAGNI ruthlessly

- Don't add complexity for hypothetical future requirements
- If you suggest an enhancement, be honest about whether it's needed now or later
- Three similar lines of code is better than a premature abstraction
- The right amount of design is the minimum needed for the current goals
- When suggesting production patterns, clearly label what's "v1" vs "future enhancement"

---

## Context File Management

### Files

| File | Purpose | This skill's access |
|------|---------|-------------------|
| `.context/project/domain.md` | **What the real world looks like** — the problem domain, entity types, relationships, lifecycles, terminology. Optional — only for projects with non-trivial domains | Create, Edit |
| `.context/project/design.md` | **What** we're building and **why** — behaviour, workflows, business rules | Create, Edit |
| `.context/project/architecture.md` | **How** it's built and **with what** — decisions, rationale, constraints. Always read alongside the canonical D2 diagrams | Create, Edit |
| `.context/project/data.md` | **What the data looks like** — schemas, models, contracts, concrete examples | Create, Edit |
| `.context/project/integrations.md` | **What we connect to** — external services, their APIs, auth, constraints, and tested behaviour | Create, Edit |
| `.context/project/*.d2` | **Canonical diagrams** — component structure, data flow, domain relationships. D2 source is the machine-readable representation; PNGs are rendered for humans | Create, Edit |

### The Boundary Rule

> **If you changed it, would the user experience change, the code structure change, the shape of data change, is it about an external service, or does it describe how the real world works?**
>
> - Real-world domain knowledge → `domain.md` (how the world works, independent of our software)
> - User experience changes → `design.md`
> - Code structure changes → `architecture.md` (rationale/decisions) + canonical `.d2` diagrams (visual structure)
> - Data shape changes → `data.md`
> - External service details → `integrations.md` (the service's APIs, auth, constraints, tested behaviour)
> - Domain + design → `domain.md` owns how the **real-world system** works. `design.md` owns how the **software uses** that knowledge. Cross-reference.
> - Domain + integrations → `domain.md` owns what an **external entity is** (e.g., "a CFR is a codification of federal regulations"). `integrations.md` owns how to **technically access** it (e.g., "eCFR API at https://www.ecfr.gov, no auth required"). Cross-reference.
> - Behaviour + data → Define the **rule** in `design.md`, define the **schema** in `data.md`, cross-reference.
> - Architecture + data → Define the **pattern/library** in `architecture.md`, define the **data contract** in `data.md`, cross-reference.
> - Architecture + integrations → `architecture.md` owns how **your code** connects to a service (client design, connection lifecycle). `integrations.md` owns what **the service itself** requires (API versions, regional endpoints, auth models, constraints). Cross-reference.

This is the single most important rule for maintaining these documents. When in doubt, apply this test.

### domain.md Owns

- How the real-world system works (legal system, medical system, financial system, etc.)
- Entity types and their real-world relationships (document types, process participants, regulatory bodies)
- Lifecycle and processes in the domain (how a law is created, how a claim is processed)
- Cross-reference and linkage patterns in the domain (how entities reference each other in the real world)
- Terminology, definitions, and glossary (domain-specific terms with precise meanings)
- Domain-specific reference diagrams (lifecycle flows, entity relationships)

### domain.md Must NOT Contain

- How the software handles domain concepts — that's `design.md`
- API endpoints or technical access details for domain data sources — that's `integrations.md`
- Data schemas for how we model domain entities in code — that's `data.md`
- Business rules about what the software does with domain knowledge — that's `design.md`
- Library or technology choices — that's `architecture.md`

**Example — WRONG in domain.md:**
> "The PTOA is fetched from GovInfo using the REST API at https://api.govinfo.gov and parsed with regex."

**Example — RIGHT in domain.md:**
> "The PTOA maps USC sections to their implementing CFR parts at section-to-part granularity. See `integrations.md` Section 7 for technical access details."

### design.md Owns

- Config specification (every key and its behavioral effect — but the model shape with types/defaults is in data.md)
- User-visible workflows and CLI behavior (what the user experiences step by step)
- Business rules and policies (version caps, resume logic, error categories, "never destroy old results")
- Console output (what the user sees at each stage)
- Cost estimation behavior (how estimates are calculated and displayed)
- All open questions and deferred items (even architectural or data ones, if unresolved)

### design.md Must NOT Contain

- Library or package names (e.g., `jsonschema`, `pymongo`) — say what the behavior is, not what implements it
- Algorithm names (e.g., "token bucket") — say what the behavior is, not how it's achieved internally
- Design pattern names (e.g., "strategy pattern", "Protocol class") — say what the system supports, not how extensibility is structured
- Module placement or component interaction details — say what happens, not which module does it
- Class, protocol, or interface names — those are architecture
- JSON examples or field-by-field schema tables — those are data.md
- Pydantic model definitions — data.md owns the shape, design.md owns the behavioral effect of each key

**Example — WRONG in design.md:**
> "Enforced by a token bucket rate limiter module that sits between the orchestrator and LLM client."

**Example — RIGHT in design.md:**
> "Rate limited to a configurable RPM. Requests exceeding the limit are queued, not dropped. 429 responses are retried with backoff."

**Example — WRONG in design.md (data leak):**
> ```json
> { "status": "success", "result": { "doc_type": "regulation" }, "config_hash": "a3f8c2" }
> ```

**Example — RIGHT in design.md:**
> "Each result has a status field (see data.md Section X). Resume logic skips `success`, retries `error`."

### architecture.md Owns

- Design patterns and their rationale (strategy pattern, protocol classes, factory functions — and WHY)
- Concurrency model (threading approach, thread-safety, connection pooling)
- Library and technology choices (which libraries, why these over alternatives)
- External dependency management (how connections are managed, pooled, lifecycle)
- Structural constraints (module layout rules, functions vs classes policy)
- Resolved architectural questions and decision log

### Canonical D2 Diagrams Own

- Component inventory with one-line responsibilities (component diagram)
- Dependency graph — who depends on whom, injection points, abstraction boundaries (component diagram)
- Data flow direction — who calls whom, who produces what for whom (pipeline contracts diagram)

These are the visual counterpart to `architecture.md`. The markdown has decisions and rationale; the diagrams have structure and flow. Always read both together.

### architecture.md Must NOT Contain

- Config key specifications (what keys exist, their types, defaults) — that's design + data
- User-facing workflow descriptions — that's design
- Business rules or policies (version caps, resume semantics) — that's design
- Restated design.md or data.md content — use cross-references instead
- JSON examples, field tables, or schema definitions — those are data.md

**Example — WRONG in architecture.md:**
> "Output at `output/{analysis_key}/run_{N}/` containing `config.yaml` (frozen snapshot), `results/{doc_id}.json` (result + source fields), `aggregation.json`."

**Example — RIGHT in architecture.md:**
> "Result Writer generates disk output in the structure defined in data.md Section X."

### integrations.md Owns

- External service API details (versions, endpoints, regional availability, model/tier selection)
- Authentication models for each service (how auth works in dev vs production)
- Tested behaviour (what has been confirmed working through actual testing, with dates)
- Service constraints and limits (rate limits, payload limits, feature availability by region/tier)
- Gotchas (things that don't work as documented, undocumented requirements)
- Pricing where it affects design decisions (e.g. choosing a model tier, enabling/disabling a feature for cost)
- Open integration questions (unresolved items that may affect design — move to `design.md` if blocking)

### integrations.md Must NOT Contain

- How your code connects to services (client design, connection pooling, error handling) — that's `architecture.md`
- Data schemas for API requests/responses — those are `data.md`
- Implementation status or task tracking — use `design.md` open questions / deferred items
- Library or package choices — that's `architecture.md`

**Example — WRONG in integrations.md:**
> "The STT client uses an async context manager with a request generator pattern."

**Example — RIGHT in integrations.md:**
> "Chirp 3 is only available in multi-region locations (us, eu) and regional locations (asia-south1). The client must target the regional endpoint: `{location}-speech.googleapis.com`."

### data.md Owns

- Database schemas (document structures, collection expectations)
- Config model (every field, type, default, validation constraint)
- API request/response shapes (what goes to/from external APIs)
- Inter-component data contracts (the shape of data at each boundary — not the flow direction)
- Output file schemas (what each disk output file contains)
- Concrete examples (actual JSON, actual YAML — the canonical reference for data shapes)

### data.md Must NOT Contain

- Behavioral rules that reference data fields — say what the field IS, not what logic uses it for
- Data flow direction (who calls whom, who produces what) — that's architecture
- Library or tool choices (Pydantic, jsonschema) — that's architecture
- Config key behavioral effects ("this key controls whether...") — that's design; data.md has the type and default only
- Open questions or deferred items — those always live in design.md

**Example — WRONG in data.md:**
> "The `status` field is used by resume logic to skip successful documents and retry errors."

**Example — RIGHT in data.md:**
> `status`: string, enum `["success", "error", "pending"]` — see design.md Section 5 for resume behaviour.

**Example — WRONG in data.md:**
> "Validated using the `jsonschema` library after translation from YAML."

**Example — RIGHT in data.md:**
> Output schema definition in YAML format, with JSON Schema equivalent. See architecture.md Section 2.3 for validation mechanism.

### Cross-Referencing

When multiple files need to mention the same topic, one file OWNS the detail and the others REFERENCE it. The owning file has the full specification. The referencing file has one line plus a pointer.

**Standard format:** Always use this pattern for cross-references:

```
See `filename.md` Section X for [brief description of what's there].
```

Always include: backtick filename, section number, and "for [what]" suffix. The suffix tells the reader whether the reference is worth following.

**Examples:**

- `design.md` says: "Resume logic skips documents with status `success` — see `data.md` Section 1 for the result schema."
- `data.md` says: `status`: string, enum `["success", "error", "pending"]`. See `design.md` Section 5 for resume behaviour.
- `architecture.md` says: "Database Client reads per-document status for resume filtering. See `data.md` Section 1 for the result schema."
- `architecture.md` says: "STT Client wraps Google Cloud Speech V2 using async streaming. See `integrations.md` Section 2 for API version, regional endpoint, and language code requirements."
- `integrations.md` says: "Chirp 3 streaming limits audio chunks to 25,600 bytes. See `architecture.md` Section 2.1 for how the client handles chunk splitting."

### Avoiding Duplication

A fact should be stated **once** in its owning file. The other files may reference it but must not restate it. If you find yourself writing the same information in multiple files, stop and apply the boundary rule to determine which file owns it.

**Acceptable:** Stating a core principle once in each file with different framing (design: "what the user relies on", architecture: "what the code must enforce", data: "what the schema guarantees").

**Not acceptable:** Restating the same specification, schema, or policy across files.

### Conventions

- **Resolved decisions** are stated as facts in the appropriate document
- **Open questions** live in a dedicated section of `design.md` with enough context that a new agent understands why it's open and what the options are
- **Deferred items** live in a dedicated section of `design.md`, marked with a reason and whether they block implementation
- **`architecture.md` contains ONLY resolved decisions** — if it's not settled, it doesn't go in this file. Even if the topic is architectural, if it's still open it lives in `design.md`
- **`data.md` contains ONLY resolved schemas** — if a data shape isn't finalised, it doesn't go in this file. Note the open question in `design.md` and add the schema to `data.md` once resolved
- **`integrations.md` contains ONLY confirmed behaviour** — document what has been tested or verified from official documentation. Assumptions and untested expectations live in `design.md` as open questions until confirmed
- **`domain.md` contains ONLY verified domain knowledge** — document what has been confirmed from authoritative sources. If the domain understanding is uncertain, note it as an open research item in `design.md`

### Document Headers

Each document has a standard header defined in its template (see Templates section). The Design Status block in `design.md` must be updated every session based on actual document contents — it gives instant orientation without reading the full doc.

---

## Templates

Document templates live in the skill's `templates/` directory. Copy them via CLI rather than recreating from memory — this saves context and eliminates hallucination risk.

- `domain.md`: `~/.claude/skills/dev-project-planning/templates/domain.md` (optional — for projects with non-trivial domains)
- `design.md`: `~/.claude/skills/dev-project-planning/templates/design.md`
- `architecture.md`: `~/.claude/skills/dev-project-planning/templates/architecture.md`
- `data.md`: `~/.claude/skills/dev-project-planning/templates/data.md`
- `integrations.md`: `~/.claude/skills/dev-project-planning/templates/integrations.md`

**Usage:** Copy all templates into `.context/project/` at project start (see Orientation Protocol Step 1). Read the copied file before editing it — the template's HTML comments explain what goes in each section. If the project doesn't have a complex domain, `domain.md` can be removed.

**Unused sections:** If a section doesn't apply to the project, mark it `N/A — not applicable for this project` rather than deleting it. This keeps section numbering stable for cross-references across all four documents.

**Project-specific sections:** Templates include placeholder zones for adding sections specific to the project. Keep numbering sequential. In `design.md`, Open Questions and Deferred Items are always the last two sections regardless of how many project-specific sections are added.

---

## Handoff to Sprint Development

The design phase is complete when:

1. All blocking open questions are resolved
2. Deferred items are confirmed non-blocking with clear reasoning
3. `design.md` has clear scope, workflows, and a resolved details section
4. `architecture.md` has decisions, rationale, constraints, and key architectural questions resolved
5. Canonical D2 diagrams exist for component structure and data flow (at minimum)
6. `data.md` has schemas, models, and data contracts for all key structures
7. `integrations.md` has tested configurations for external services the design depends on (if applicable — not all projects have external service dependencies)
8. Design Status block shows "Sprint ready: Yes"

At this point, tell the user: "The design is sprint-ready. The next step is to invoke `dev-sprint-development` as a Manager to plan the sprint chunks."

### What gets handed off

The Sprint Development Manager reads `domain.md` (if it exists), `design.md`, `architecture.md` (alongside the canonical D2 diagrams), `data.md`, and `integrations.md` as their starting context. These documents and diagrams must be self-contained — the Manager should not need any other context to understand what's being built and how.

---

## What This Skill Does NOT Do

| Don't | Why |
|-------|-----|
| Create sprint files, PLAN.md, or ACTIVE-SPRINT | That's `dev-sprint-development` Manager's job |
| Write implementation plans or chunk scopes | That's the Implementer's job |
| Make implementation-level decisions (specific library versions, exact file paths) | Those belong in sprint planning, not design |
| Write code | This is design phase |
| Define sprint chunks or ordering | Chunks come from a mature design; the Manager creates them |
| Accept "it's fine" without thinking critically | Your job is to find problems before implementation does |

---

## Skills

**Load on-demand:**
- `brainstorming` → for structured design conversations (one topic at a time, options with tradeoffs)
- `dev-standards` → when evaluating whether a design meets production standards for its maturity tier
- `dev-diagrams` → during architecture design, to discuss which diagram types would help document the project and generate them. Load when the design is mature enough that structure, data models, or data flows are taking shape. Canonical diagrams are maintained alongside `architecture.md` in `.context/project/` — store both D2 source (`.d2`) and rendered PNG files
