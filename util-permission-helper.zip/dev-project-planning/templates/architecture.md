# [Project Name] - Architecture

**Created:** YYYY-MM-DD
**Companion to:** `design.md` (behaviour and workflows), `data.md` (schemas and data contracts), `integrations.md` (external service details)

---

## 1. System Overview

<!-- High-level description: what kind of system is this? (CLI tool, API service, library, etc.) -->
<!-- Key technical facts: language, packaging, entry point. -->
<!-- Include a simple ASCII pipeline or flow diagram if helpful. -->

## 2. Component Map

<!-- Table of components with one-line responsibilities. -->
<!-- Then a dependency tree showing who depends on whom. -->
<!-- Add subsections (2.1, 2.2, ...) for components that need design rationale. -->
<!-- Cross-reference: See `data.md` Section 4 for inter-component data contracts. -->

## 3. Concurrency Model

<!-- N/A if not applicable — keep the section for stable cross-references. -->
<!-- Threading, async, multiprocessing? What's parallelised and why? -->
<!-- Thread-safety considerations, shared state, connection pooling. -->

## 4. Data Flow

<!-- How data moves between components. Who calls whom, who produces what for whom. -->
<!-- This is about component wiring, not data shapes — schemas live in data.md. -->
<!-- Cross-reference: See `data.md` Section 4 for the shape of data at each boundary. -->

## 5. External Dependencies

<!-- Table: dependency, usage, connection management. -->
<!-- How external connections are created, pooled, shared, and cleaned up. -->

## 6. Key Constraints

<!-- Structural constraints (how the code is organised). -->
<!-- Behavioural constraints the code must enforce (cross-reference design.md for the rules). -->

## 7. Resolved Architectural Questions

<!-- Table: question, decision. Each links back to the relevant subsection above. -->
<!-- Only include questions where there was a genuine choice between alternatives. -->
<!-- Cross-reference: design.md for design-level decisions, data.md for schema decisions. -->
