# [Project Name] - Data Models & Contracts

**Created:** YYYY-MM-DD
**Companion to:** `design.md` (behaviour and workflows), `architecture.md` (code structure), `integrations.md` (external service details)

---

## 1. Config Model

<!-- Complete configuration schema. Every field, type, default, validation constraint. -->
<!-- Organised by config group (subsections 1.1, 1.2, ...). -->
<!-- Behavioral effects of each key live in design.md — here we define the shape only. -->
<!-- Cross-reference: See `design.md` Section 3 for what each config key does. -->

---

<!-- ============================================================ -->
<!-- PROJECT-SPECIFIC DATA SECTIONS                                -->
<!-- Add sections here for your project's data models. Common:     -->
<!--   - Database schemas (document structures, collections)       -->
<!--   - API request/response shapes                               -->
<!--   - Stored result schemas (what gets written where)           -->
<!-- Include concrete JSON/YAML examples for each schema.          -->
<!-- Keep numbering sequential.                                    -->
<!-- ============================================================ -->

---

## 2. Output / Storage Schemas

<!-- Schemas for data written to disk, databases, or external systems. -->
<!-- Include concrete examples (actual JSON, actual YAML). -->
<!-- Cross-reference: See `design.md` for storage policies (caps, retention, etc.). -->

---

## 3. Inter-Component Data Contracts

<!-- The shape of data at each internal boundary between components. -->
<!-- This is about what the data looks like, not who sends it where — flow direction is in architecture.md. -->
<!-- Cross-reference: See `architecture.md` Section 4 for data flow direction. -->
