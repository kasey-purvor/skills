# [Project Name] - Design Document

**Created:** YYYY-MM-DD
**Companion to:** `architecture.md` (code structure), `data.md` (schemas and data contracts), `integrations.md` (external service details)

## Design Status
- **Last updated:** YYYY-MM-DD
- **Open questions:** 0
- **Deferred items:** 0
- **Sprint ready:** No

---

## 1. Purpose & Scope

<!-- What are we building and why? Key use cases, core principles, explicit out-of-scope items. -->
<!-- Cross-reference: architecture.md for how it's built, data.md for data models. -->

---

## 2. User Interface

<!-- Entry points, commands, flags, interactions. What the user types and sees. -->
<!-- For CLI tools: entry point, flags table, flag interactions. -->
<!-- For APIs: endpoints overview, authentication approach. -->
<!-- For libraries: public API surface. -->

---

## 3. Configuration

<!-- Every config key and its behavioral effect. What each key DOES, not what type it IS. -->
<!-- The config model schema (types, defaults, constraints) lives in data.md. -->
<!-- Cross-reference: See `data.md` Section 1 for the config model schema. -->

---

## 4. Core Workflow

<!-- Happy path step by step. What happens from start to finish when there are no errors and no existing state. -->

---

<!-- ============================================================ -->
<!-- PROJECT-SPECIFIC SECTIONS                                     -->
<!-- Add sections here as needed for your project. Common topics:  -->
<!--   - Repeat/resume behaviours                                  -->
<!--   - Error handling                                            -->
<!--   - Console output / user experience                          -->
<!--   - Cost estimation or resource management                    -->
<!--   - Future considerations                                     -->
<!-- Keep numbering sequential.                                    -->
<!-- Open Questions and Deferred Items are always the last two.    -->
<!-- ============================================================ -->

---

## 5. Open Questions

<!-- Unresolved design decisions. Each entry needs: -->
<!--   - The question                                -->
<!--   - Why it matters                              -->
<!--   - Known options with tradeoffs (if any)       -->
<!--   - Whether it blocks implementation            -->

None.

---

## 6. Deferred Items

<!-- Items confirmed non-blocking for implementation. Each entry needs: -->
<!--   - What it is                                                     -->
<!--   - Why it's deferred                                              -->
<!--   - Blocking? (always No for items in this section)                -->

None.
