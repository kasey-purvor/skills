# [Project Name] - Domain Knowledge

**Created:** YYYY-MM-DD
**Companion to:** `design.md` (what we're building), `integrations.md` (how we access domain data sources)

---

<!-- This file documents the problem domain your project operates in.        -->
<!-- It describes how the REAL WORLD works, independent of your software.    -->
<!-- Understanding the domain is prerequisite to designing the software.     -->
<!--                                                                         -->
<!-- How your software uses this knowledge lives in design.md.               -->
<!-- How you technically access domain data sources lives in integrations.md. -->
<!--                                                                         -->
<!-- Not every project needs this file. Simple tools or libraries with no    -->
<!-- complex domain may skip it. Create it when the project operates in a    -->
<!-- domain that requires understanding before you can design the software.  -->

## 1. Domain Overview

<!-- Brief description of the domain. What real-world system are we operating in? -->
<!-- Why does this domain need to be understood before we can build the software? -->

---

## 2. Entity Types & Relationships

<!-- What are the key entities in this domain? How do they relate to each other? -->
<!-- Use tables for structured comparisons. Reference D2 diagrams for visuals.  -->

---

## 3. Lifecycle & Processes

<!-- How do things flow in this domain? What are the key processes?             -->
<!-- E.g., how a law is created, how a claim is processed, how data moves.     -->
<!-- Reference D2 diagrams for visual representation of lifecycle flows.        -->

---

## 4. Cross-References & Linkages

<!-- How do entities reference each other? What patterns exist?                 -->
<!-- What tools or indices exist for navigating between entities?               -->

---

## 5. Terminology & Glossary

<!-- Domain-specific terms with precise meanings.                               -->
<!-- Only include terms that matter for the software's purpose.                 -->
<!-- Use a table: Term | Meaning                                                -->

---

<!-- ============================================================ -->
<!-- PROJECT-SPECIFIC SECTIONS                                     -->
<!-- Add sections here as needed for your domain. Examples:         -->
<!--   - Regulatory framework structure                            -->
<!--   - Industry classification systems                           -->
<!--   - Geographic or jurisdictional variations                   -->
<!--   - Data quality and reliability considerations               -->
<!-- Keep numbering sequential.                                    -->
<!-- ============================================================ -->
