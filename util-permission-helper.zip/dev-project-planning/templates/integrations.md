# [Project Name] - External Service Integrations

**Created:** YYYY-MM-DD
**Companion to:** `architecture.md` (how your code connects to services), `design.md` (behaviour and workflows), `data.md` (schemas and data contracts)

---

<!-- This file documents the external services your project depends on.    -->
<!-- One section per service. Each section captures what you need to know  -->
<!-- about the SERVICE ITSELF — its APIs, auth, constraints, and gotchas.  -->
<!--                                                                       -->
<!-- How your CODE connects to these services lives in architecture.md     -->
<!-- (Section 5: External Dependencies). This file is about what's on the  -->
<!-- other side of that connection.                                         -->
<!--                                                                       -->
<!-- Not every service needs every subsection. A local database might be   -->
<!-- 3 lines. A complex cloud API with regional constraints, multiple      -->
<!-- auth models, and undocumented quirks might need a full page.           -->
<!-- Document what matters — skip what doesn't.                            -->

<!-- ============================================================ -->
<!-- SERVICE SECTIONS                                               -->
<!-- Add one section per external service. For each, consider:      -->
<!--                                                                -->
<!--   Auth: How does authentication work? Does it differ between   -->
<!--         dev and production? What credentials, roles, or        -->
<!--         permissions are needed?                                -->
<!--                                                                -->
<!--   API: Which version, endpoints, or regional constraints?      -->
<!--        What model/tier/plan is being used and why?             -->
<!--                                                                -->
<!--   Tested behaviour: What has been confirmed working through    -->
<!--         actual testing? What doesn't work as documented?       -->
<!--         Include dates — API behaviour changes over time.       -->
<!--                                                                -->
<!--   Constraints: Rate limits, payload limits, feature            -->
<!--         availability by region/tier, language support,         -->
<!--         concurrency limits.                                    -->
<!--                                                                -->
<!--   Pricing: Only if it's a paid external service where cost     -->
<!--         decisions affect the design (e.g. choosing a model     -->
<!--         tier, enabling/disabling a feature for cost reasons).  -->
<!--                                                                -->
<!-- Keep numbering sequential.                                     -->
<!-- ============================================================ -->

## 1. Open Integration Questions

<!-- Unresolved integration questions that may affect design decisions.   -->
<!-- Move to design.md Open Questions if they block implementation.       -->
<!-- Remove from here once resolved and documented in the service section. -->

None.
