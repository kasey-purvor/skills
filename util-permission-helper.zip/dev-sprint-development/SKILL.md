---
name: dev-sprint-development
description: Use at the start of every development session - establishes .context/ folder structure, enforces skill usage, tracks progress via CURRENT-STATE.md
---

# Sprint Development

## Overview

Entry point for all sprint development work. Defines three roles with clear constraints on what each can and cannot do. User supervises all roles and coordinates between them.

**On initialization, ask:** "What's my role, and what's the current state of the work?"

**Then read your role file** at `~/.claude/skills/dev-sprint-development/roles/{role}.md` before proceeding:
- Manager → `roles/manager.md`
- Implementer → `roles/implementer.md`
- Junior Developer → `roles/junior-developer.md`

---

## Roles

| Role | Focus | Persistence |
|------|-------|-------------|
| **Manager** | Design, chunking, oversight | Long-lived (whole sprint) |
| **Implementer** | Detailed plans, gap-filling, review | Medium (multiple chunks) |
| **Junior Developer** | Execute plans exactly | Ephemeral (single plan execution) |

### Skills by Role

Skills are either **Init** (load immediately on initialization, before any work) or **On-demand** (load when triggered by a specific situation). Init skills shape how the role thinks about all work. On-demand skills are procedures invoked at specific moments.

| Skill | Manager | Implementer | Junior Developer |
|-------|---------|-------------|------------------|
| `writing-plans` | - | **Init** | - |
| `executing-plans` | - | - | **Init** |
| `test-driven-development` | - | **Init** | **Init** |
| `systematic-debugging` | - | On-demand | **Init** |
| `verification-before-completion` | On-demand | On-demand | **Init** |
| `brainstorming` | On-demand | On-demand | - |

---

## Folder Structure

```
.context/
├── project/
│   ├── design.md
│   ├── architecture.md
│   ├── data.md
│   ├── component-diagram.d2      (canonical — maintained)
│   ├── component-diagram.png
│   ├── pipeline-contracts.d2     (canonical — maintained)
│   └── pipeline-contracts.png
├── sprints/
│   ├── YYYY-MM-DD-<sprint-name>/
│   │   ├── PLAN.md
│   │   ├── CURRENT-STATE.md
│   │   ├── implementation/
│   │   │   ├── 01-<chunk-name>.md
│   │   │   └── ...
│   │   ├── temp-diagrams/
│   │   │   └── (temporary context diagrams — brainstorming aids, not maintained)
│   │   └── SPRINT-SUMMARY.md
│   └── ...
└── ACTIVE-SPRINT
```

**ACTIVE-SPRINT:** Contains full path to current sprint from project root (e.g., `.context/sprints/2026-02-03-user-auth/`). Skills read this file and use the path directly without modification.

---

## Project Context

Project context files in `.context/project/` are the project's source of truth: `design.md`, `architecture.md` (read alongside the canonical `.d2` diagrams), and `data.md`. Sprint work must be consistent with them. If a sprint decision would conflict with a context file, escalate to the user — don't silently override the design.

**Access by role:**

| Role | Context file access |
|------|-------------------|
| **Manager** | Read all project context files on init — the three markdown files plus all `.d2` diagram files in `.context/project/`. Check for other files in `.context/project/` and ask the user whether they should be read. The Manager is responsible for ensuring chunk scopes and decisions are consistent with these files and diagrams. |
| **Implementer** | Read on-demand only, when the chunk scope section references a specific section (e.g., "see `data.md` Section 5 for the audit log schema"). The chunk scope is the Implementer's primary input — context files fill in referenced details. |
| **Junior Developer** | Never reads context files. The implementation plan contains everything needed for execution. |

### Canonical Diagram Maintenance

The canonical `.d2` diagrams in `.context/project/` (component diagram, pipeline contracts) reflect the project's module structure and data flow. When implementation changes add, remove, or restructure modules or change data flow between components:

1. **Identify the change** — note which diagram(s) would be affected
2. **Ask the user for confirmation** — do NOT update diagrams without explicit user approval. The user may prefer to batch diagram updates or skip the update entirely
3. **If approved**, update the `.d2` source and re-render the `.png`

This applies to **Manager and Implementer** roles. The Junior Developer does not touch canonical diagrams.

## Production Engineering Mindset

Applies to **Manager and Implementer** roles. When making or evaluating technical decisions during the sprint:

- **Explain the "why"** behind patterns — "do X because without it, Y happens"
- **Reference real-world practice** — how production systems and open-source projects actually handle it
- **Name the tradeoff** between simple and professional approaches — be explicit about what matters at this project's scale
- **Challenge skipped fundamentals** — error handling, logging, data integrity, testability
- **YAGNI** — don't gold-plate, but don't skip what production code needs

This does NOT apply to the Junior Developer role. Juniors execute plans, not engineering judgments.

---

## File Ownership Matrix

| File | Manager | Implementer | Junior Developer |
|------|---------|-------------|------------------|
| **PLAN.md** | Create, Edit | Read | Read |
| **CURRENT-STATE.md** | Create, Edit | Edit | Read |
| **implementation/*.md** | Read | Create, Edit | Checkboxes + notes only |
| **SPRINT-SUMMARY.md** | Create, Edit | Read | Read |
| **ACTIVE-SPRINT** | Create, Edit | Read | Read |

---

## Task and Step Notation

Implementation plans use Tasks (logical units) containing Steps (individual actions).

**Decimal notation:** `Task.Step` — e.g., `1.1` = Task 1, Step 1; `2.3` = Task 2, Step 3

**Progress notation for CURRENT-STATE.md:** `✅1.1 ✅1.2 🔄1.3 ⬜1.4`

---

## Deviation Tracking

Deviations recorded in two places:

1. **Implementation Plan** (Junior records): Detailed note under the task — what changed, why, file references
2. **CURRENT-STATE.md** (Implementer summarizes): Task ID + brief summary in Deviations table

---

## Sub-Agent Prompts (User-Invoked Only)

These are manually dispatched by the user when reviewing Junior's completed work — not invoked by any role automatically.

- `sub-agents/code-review-prompt.md` — Quality, correctness, edge cases
- `sub-agents/spec-adherence-prompt.md` — Plan compliance, deviation detection
