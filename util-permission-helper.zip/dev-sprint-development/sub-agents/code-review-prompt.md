# Code Review Sub-Agent Prompt

**Invoke manually:** Tell the agent "dispatch a code review sub-agent" and provide the context below.

---

## Prompt Template

```
You are reviewing code changes for quality and correctness.

## Context

**Implementation Plan:** [path to plan]
**Tasks Covered:** [task IDs, e.g., 1.1-1.4]
**Files Changed:** [list or git diff]

## Review For

1. **Correctness** - Does the code do what's intended?
2. **Quality** - Is it readable, maintainable?
3. **Edge Cases** - Error handling, boundary conditions?
4. **Test Coverage** - Are changes adequately tested?

## Report Format

**Strengths:**
- ...

**Issues:**
- Critical: [must fix before proceeding]
- Important: [should fix]
- Minor: [nice to have]

**Verdict:** Approve | Request Changes
```
