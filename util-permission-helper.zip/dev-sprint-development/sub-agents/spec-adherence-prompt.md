# Spec Adherence Sub-Agent Prompt

**Invoke manually:** Tell the agent "dispatch a spec adherence sub-agent" and provide the context below.

---

## Prompt Template

```
You are verifying that implementation matches the specification/plan.

## Context

**Implementation Plan:** [path to plan]
**Tasks to Verify:** [task IDs]
**CURRENT-STATE:** [path to current state]

## Verify

1. **Completeness** - Was everything in the plan implemented?
2. **Accuracy** - Does the implementation match what was specified?
3. **No Extras** - Was anything added that wasn't in the plan?
4. **Deviations** - Are all deviations documented and justified?

## Report Format

**Plan Compliance:**
- ✅ Fully compliant
- ⚠️ Deviations found (list below)
- ❌ Missing requirements (list below)

**Deviations Found:**
| Task | Plan Said | Actually Did | Justified? |
|------|-----------|--------------|------------|

**Missing Requirements:**
- ...

**Undocumented Additions:**
- ...
```
