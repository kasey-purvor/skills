# Sprint State: [Sprint Name]

**Sprint Folder:** `.context/sprints/YYYY-MM-DD-<sprint-name>/`
**Last Updated:** YYYY-MM-DD HH:MM
**Updated By:** [agent role / person]
**Sprint Goal:** [one sentence]
**Jira:** [ticket/epic link]

## Status

🟢 On Track | 🟡 At Risk | 🔴 Blocked

## Chunk Progress

| Chunk | Plan | Status | Progress |
|-------|------|--------|----------|
| 01 | [01-name.md](./implementation/01-name.md) | 🔄 In Progress | ✅1.1 ✅1.2 🔄1.3 ⬜1.4 |
| 02 | [02-name.md](./implementation/02-name.md) | ⬜ Not Started | |

## Current Work

**Chunk:** 01
**Task:** 1.3
**State:** [brief description of where we are]

## Deviations

| Task | Summary |
|------|---------|
| | |

## Blockers

- None

## Notes for Next Session

- ...
