# Standards Matrix

Quick reference for what's required at each tier.

**Status:** Work in Progress — Topics being developed

| Topic | Prototype | Internal | Production |
|-------|-----------|----------|------------|
| Testing | TDD only | TDD + explicit edge cases | TDD + edge cases + templates + mutation testing |
| Error Handling | Fail fast, console output | Catch + log, basic retry | Categorized handling, retry + backoff, user-friendly messages |
| Logging | Console summary + progress, optional file | Console + file logging, configurable verbosity | Console + structured (JSON), full context, queryable |
| Security | .env secrets, basic validation | + parameterized queries, encryption at rest | + secret manager, auth/authz, audit logging, dependency scanning |
| Configuration | .env + os.getenv with defaults | + YAML config, Pydantic models, @lru_cache singleton | + startup validation, clear error messages |
| Monitoring | Console output, manual checks | Persistent logs, post-run summaries | Metrics, alerting, dashboards, log aggregation |
| Reliability | Basic try/catch, log errors | Retry + backoff, timeouts, log failures | + idempotency, dead letter handling, checkpointing |
| Data Integrity | Basic type hints, ad-hoc validation | Pydantic for external data, type hints | Models folder, strict typing, all boundaries validated |
| Documentation | README with setup instructions | + Docstrings, architecture diagram | + API docs, runbooks, decision records |

---

## Detailed Requirements

*(Filled in as topics are finalized)*
