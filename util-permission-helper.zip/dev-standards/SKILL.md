---
name: dev-standards
description: Use when you need guidance on production code standards across different maturity tiers (prototype, internal, production) - covers testing, error handling, logging, security, configuration, monitoring, reliability, data integrity, and documentation
---

# Standards

## Overview

Reference material for production code standards across different maturity tiers. Load this skill when you need guidance on what "good" looks like for a given context.

**This skill provides the WHAT. Workflow skills (like sprint-context-management) provide the HOW.**

## When to Load

- Starting a sprint that targets a specific quality tier
- Productionizing existing code
- Code review against defined standards
- Planning implementation that needs specific standards guidance

## Tiers

| Tier | Use Case | Rigour |
|------|----------|--------|
| **Prototype** | Exploring feasibility, throwaway code | Minimal |
| **Internal** | Team tools, internal services | Moderate |
| **Production** | Customer-facing, critical systems | Full |

## Structure

- `MATRIX.md` — Quick reference: what's required at each tier per topic
- `topics/*.md` — Deep dives on each topic

## Topics

1. Testing
2. Error Handling
3. Logging
4. Security
5. Configuration
6. Monitoring
7. Reliability
8. Data Integrity
9. Documentation

## Usage

1. Identify your tier (prototype/internal/production)
2. Check MATRIX.md for requirements at that tier
3. Reference topic files for detailed guidance

---

**Status:** Work in Progress
