# Configuration Standards

**Status:** Draft

## Core Principle

Configuration should be centralized, typed, and validated. Follow the established multi-layer pattern from existing projects.

---

## Reference Implementation

See: `/home/kasey/dev_wsl/Cloud_assist/Compliance_app/leg_parser_usa/config/settings.py`

This is the gold standard for configuration handling.

---

## Tier Requirements

### Prototype

- `.env` file for secrets (gitignored)
- `os.getenv()` with inline defaults
- Single `load_dotenv()` call at entry point

### Internal

- Centralized config loading (single module)
- Pydantic models with Field defaults for type safety
- YAML file for domain/tunable settings
- `@lru_cache` on config loader (singleton pattern)

### Production

- All Internal requirements
- Validate ALL required vars at startup (fail fast)
- Clear error messages listing missing vars
- Environment-specific config files if needed

---

## Established Patterns

### Multi-Layer Configuration

```
Priority (highest to lowest):
1. Environment variables (.env) — secrets, overrides
2. YAML config file — domain settings, tunables
3. Pydantic model defaults — sensible fallbacks
4. Code defaults — last resort
```

### Directory Structure

```
project/
├── config/
│   ├── settings.py      # Pydantic models + get_config()
│   └── parser_config.yaml  # Domain settings
├── .env                 # Secrets (gitignored)
└── .env.example         # Template for required vars
```

### Singleton Config Loading

```python
from functools import lru_cache
from pydantic import BaseModel
import yaml
import os
from dotenv import load_dotenv

load_dotenv()  # Once at module load

@lru_cache
def get_config() -> Config:
    """Load and cache configuration from YAML."""
    config_path = CONFIG_DIR / "parser_config.yaml"

    if not config_path.exists():
        return Config()  # Defaults if no config file

    with open(config_path, encoding="utf-8") as f:
        data = yaml.safe_load(f)

    return Config(**data)
```

### Pydantic Models with Defaults

```python
from pydantic import BaseModel, Field

class FetchSettings(BaseModel):
    rate_limit_seconds: float = 0.5
    request_timeout: int = 30
    connect_timeout: int = 10
    max_retries: int = 3
    retry_backoff_factor: float = 2.0

class DatabaseSettings(BaseModel):
    database_name: str = "my_database"
    collections: dict = Field(default_factory=lambda: {
        "items": "items",
        "logs": "logs"
    })

class Config(BaseModel):
    fetch: FetchSettings = Field(default_factory=FetchSettings)
    database: DatabaseSettings = Field(default_factory=DatabaseSettings)
```

### Environment Variable Properties

```python
class MongoDBSettings(BaseModel):
    """Settings loaded from environment."""

    @property
    def uri(self) -> Optional[str]:
        return os.getenv("MONGODB_URI")

    @property
    def db_name_override(self) -> Optional[str]:
        return os.getenv("MONGODB_DB_NAME")
```

### Startup Validation (Production)

```python
def validate_required_config():
    """Call at application startup. Fails fast with clear message."""
    required = {
        "MONGODB_URI": os.getenv("MONGODB_URI"),
        "OPENAI_API_KEY": os.getenv("OPENAI_API_KEY"),
    }

    missing = [k for k, v in required.items() if not v]

    if missing:
        raise ConfigurationError(
            f"Missing required environment variables: {', '.join(missing)}\n"
            f"See .env.example for required configuration."
        )
```

---

## What Goes Where

| Type of Config | Location | Example |
|----------------|----------|---------|
| **Secrets** | `.env` (environment) | API keys, database passwords |
| **Tunables** | YAML file | Rate limits, batch sizes, timeouts |
| **Structural** | Pydantic defaults | Collection names, URL patterns |
| **Constants** | Code | Magic numbers that never change |

---

## YAML Config Example

```yaml
# config/parser_config.yaml

fetch:
  rate_limit_seconds: 0.5
  request_timeout: 30
  max_retries: 3

chunking:
  batch_size: 100
  checkpoint_interval: 100

database:
  database_name: "my_app"
  collections:
    items: "items"
    logs: "process_logs"

logging:
  level: "INFO"
  max_file_size_mb: 10
  backup_count: 5
```

---

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Scatter `load_dotenv()` across files | Single call at entry point |
| Hardcode secrets in code | Use environment variables |
| Use raw `os.getenv()` everywhere | Centralize in config module |
| Skip validation for "obvious" vars | Validate all required vars at startup |
| Mix secrets into YAML | YAML for tunables, .env for secrets |

---

## Tooling

| Language | Config Library | Validation |
|----------|----------------|------------|
| Python | `pydantic`, `python-dotenv`, `pyyaml` | Pydantic |
| TypeScript | `dotenv`, `zod` | Zod schemas |
| JavaScript | `dotenv`, `joi` | Joi schemas |

---

## Expand During Brainstorming

When starting a new project, discuss:

- What settings need to vary between environments?
- What's a secret vs a tunable?
- Are there environment-specific configs needed? (dev.yaml, prod.yaml)
- Feature flags requirements?
