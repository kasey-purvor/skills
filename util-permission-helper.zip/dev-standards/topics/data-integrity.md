# Data Integrity Standards

**Status:** Draft

## Core Principle

Data should be validated at boundaries, typed throughout, and stored correctly. Use models to define contracts between components.

---

## Related Topics

- **Idempotency**: See [Reliability Standards](./reliability.md)
- **Config validation**: See [Configuration Standards](./configuration.md)

---

## Tier Requirements

### Prototype

- Basic type hints
- Validation where convenient
- No formal model structure required

### Internal

- Pydantic models for external data (API responses, user input)
- Type hints throughout
- Validation at entry points

### Production

- **Models folder** with Pydantic models organized by concern
- All external data validated through models
- All database documents have corresponding models
- Strict typing (Literal types for enums, no loose strings)

---

## Reference Implementation

See: `/home/kasey/dev_wsl/Cloud_assist/Compliance_app/rule_extraction/models/`

This demonstrates production-grade model organization.

---

## Models Folder Structure

For Production tier, organize models by concern:

```
src/
└── models/
    ├── __init__.py       # Re-exports
    ├── common.py         # Shared infrastructure
    ├── <domain1>.py      # Domain-specific models
    └── <domain2>.py      # Domain-specific models
```

---

## Established Patterns

### Nested Composition

Build complex structures from simple building blocks:

```python
class Address(BaseModel):
    street: str
    city: str
    country: str

class User(BaseModel):
    name: str
    address: Address  # Nested model
```

### Literal Types for Enums

Use `Literal` for strict valid values:

```python
from typing import Literal

class Rule(BaseModel):
    modality: Literal["must", "must_not", "may", "shall"]
    status: Literal["active", "draft", "archived"]
```

### Optional Fields for Flexibility

Allow graceful degradation and extensibility:

```python
class Result(BaseModel):
    value: str
    confidence: Optional[float] = None
    reasoning: Optional[str] = None
```

### Factory Methods and Defaults

Generate IDs and timestamps automatically:

```python
from datetime import datetime, timezone
from secrets import token_hex

class Run(BaseModel):
    run_id: str = Field(default_factory=lambda: f"run_{token_hex(4)}")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
```

### Database Serialization

Add methods for database compatibility:

```python
class Document(BaseModel):
    created_at: datetime

    def to_mongo_dict(self) -> dict:
        data = self.model_dump()
        data["created_at"] = self.created_at.isoformat()
        return data
```

### Discriminated Unions

Handle polymorphic data with type discriminators:

```python
class ExtractedItem(BaseModel):
    item_type: Literal["rule", "definition", "other"]
    rule_content: Optional[RuleContent] = None
    definition_content: Optional[DefinitionContent] = None
    other_content: Optional[OtherContent] = None
```

---

## Validation Boundaries

Validate data when it crosses trust boundaries:

| Boundary | Example | Validation |
|----------|---------|------------|
| **External API → App** | Third-party response | Parse into Pydantic model |
| **User input → App** | Form submission | Validate with model |
| **File → App** | CSV/JSON import | Validate each record |
| **App → Database** | Insert/update | Model ensures correct shape |
| **Database → App** | Query result | Parse into model (optional but recommended) |

---

## Tooling

| Language | Model Library | Validation |
|----------|---------------|------------|
| Python | `pydantic` | Built-in |
| TypeScript | `zod`, interfaces | Zod for runtime |
| JavaScript | `joi`, `yup` | Runtime validation |

---

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Pass raw dicts between functions | Define models for data structures |
| Use loose strings for enums | Use `Literal` types |
| Scatter validation throughout code | Validate at boundaries via models |
| Skip validation for "trusted" internal data | Trust the model, validate at entry |
| Store unvalidated external data | Always parse through model first |

---

## Expand During Brainstorming

For each project, determine:

1. What external data sources exist? (APIs, files, user input)
2. What database collections/tables are needed?
3. What models should be shared vs domain-specific?
4. Are there polymorphic data types requiring discriminators?
5. What metadata (confidence, timestamps, provenance) should be tracked?
