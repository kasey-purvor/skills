# Testing Standards

**Status:** Draft

## Core Principle

TDD is mandatory at all tiers. AI agents must always write tests first — no exceptions.

---

## Tier Requirements

### Prototype

**TDD only.** The red-green-refactor cycle produces baseline tests. No additional requirements.

- Write failing test
- Write minimal code to pass
- Refactor
- Repeat

This naturally produces tests for implemented functionality, sufficient for throwaway/exploratory code.

### Internal

**TDD + Explicit edge cases in plan.**

The Implementer must specify edge cases when writing the plan. AI executes against the list.

Example in plan:
```markdown
### Test: validate_email()
- Valid: standard format, subdomains, plus addressing
- Invalid: missing @, missing domain, spaces, empty string
- Boundary: max length (254 chars), min length (3 chars)
```

### Production

**TDD + Edge cases + Templates + Mutation testing.**

All Internal requirements, plus:

1. **Test case templates** — Use predefined checklists for common patterns (see Templates section)
2. **Mutation testing** — Run `mutmut` (or equivalent) on changed files; surviving mutants must be addressed

---

## Test Types

| Type | Scope | When Required |
|------|-------|---------------|
| **Unit** | Single function/class | All tiers |
| **Integration** | Components working together | Internal, Production |
| **End-to-end** | Full user flows | Production (critical paths) |

---

## Test Case Templates

Reference these when writing plans for common patterns.

### Validation Function

```
- Valid input → returns true/success
- Empty input → appropriate response
- Null/undefined → appropriate response
- Type mismatch → appropriate response
- Boundary: minimum valid value
- Boundary: maximum valid value
- Just outside boundaries (off-by-one)
```

### CRUD Operation

```
- Create: valid data → success
- Create: duplicate → appropriate error
- Create: missing required fields → validation error
- Read: exists → returns data
- Read: not found → appropriate error
- Update: exists → success
- Update: not found → appropriate error
- Update: partial data → handles correctly
- Delete: exists → success
- Delete: not found → appropriate error
- Delete: cascading effects (if applicable)
```

### State Machine

```
- Each valid state transition
- Invalid state transitions → rejected
- Initial state correct
- Terminal states handled
- Idempotent transitions (if applicable)
```

### API Endpoint

```
- Success case → correct status code and body
- Authentication required → 401 without token
- Authorization required → 403 without permission
- Validation error → 400 with helpful message
- Not found → 404
- Server error → 500 (and logged)
- Rate limiting (if applicable)
```

---

## Mutation Testing

**Tool:** `mutmut` (Python), `Stryker` (JavaScript/TypeScript)

**When to run:** Production tier, on changed files before merge.

**Process:**
1. Run mutation testing on modified code
2. Review surviving mutants
3. Add tests to kill surviving mutants, or document why they're acceptable

**Acceptable survivors:**
- Equivalent mutants (change doesn't affect behavior)
- Logging/cosmetic changes
- Documented exceptions

---

## Anti-Patterns

| Don't | Why |
|-------|-----|
| Test implementation details | Tests break on refactor |
| Mock your own code | Tests pass but integration fails |
| Skip edge cases "for speed" | Bugs ship to production |
| Write tests after the fact | Loses TDD benefits, tests often miss cases |
| Rely on coverage % alone | 100% coverage with useless assertions is worthless |

---

## Open Questions

- Specific coverage thresholds per tier? (Currently relying on TDD + mutation testing rather than % targets)
- E2E test framework preferences?
